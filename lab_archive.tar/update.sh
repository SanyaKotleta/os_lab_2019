sudo apt -y update
sudo apt -y upgrade
sudo apt -y install man
sudo apt -y install nano
sudo apt -y install clang-format
sudo apt -y install iputils-ping
sudo apt -y install gcc
sudo apt -y install dos2unix
sudo apt -y install libcunit1 libcunit1-doc libcunit1-dev