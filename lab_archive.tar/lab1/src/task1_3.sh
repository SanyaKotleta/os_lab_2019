#!/bin/sh
 
dt=`date '+%d/%m/%Y_%H:%M:%S'`
 pwd
echo "$dt"
echo $PATH