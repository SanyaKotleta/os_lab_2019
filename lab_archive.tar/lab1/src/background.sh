#!/bin/bash

for i in {1..10}
do
    echo "$i sec"
    sleep 1
done

echo "Done!"